// gsap.to("#box",{
//     x:1000,
//     // y:200,
//     duration:1.5,
//     delay:1,
//     // width:300+"px",
//     rotate:360,
//     backgroundColor:"blue",
//     borderRadius:"50%",
//     // scale:0.5,
//     // repeat:1,//2 bar chalega
//     // repeat:-1,//for infinite
//     // yoyo:true,



// })
// gsap.to("#box2",{
//     x:1000,
//     backgroundColor:"yellow",
//     duration:1.5,
//     delay:2.5,
// })
// gsap.to("#box3",{
//     x:1000,
//     backgroundColor:"green",
//     borderRadius:"50%",
//     duration:1.5,
//     delay:4,
// })


// gsap.from("h1",{
//     opacity:0,
//     color:"red",
//     duration:2,
//     delay:1,
//     y:40,
//     stagger:0.5, //1 1 krke chalata hai 



// })

var tl =gsap.timeline() // sara element ek ek krke chalata hai 

// tl.to("#box",{
//     x:1200,
//     rotate:360,
//     duration:1,
//     delay:1,
// })
// tl.to("#box2",{
//     x:1200,
//     rotate:360,
//     duration:1,
//     // delay:1,
// })
// tl.to("#box3",{
//     x:1200,
//     rotate:360,
//     duration:1,
//     // delay:1,
// })

var tl=gsap.timeline()

tl.from("h2",{
    y:-40,
    opacity:0,
    duration:1,
    delay:0.5,

})

tl.from("h4",{
    y:-30,
    opacity:0,
    duration:1,
    delay:0.5,
    stagger:0.3
})

tl.from("h1",{
    y:20,
    duration:1,
    scale:0,
})